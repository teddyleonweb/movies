<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class tag extends Model
{
    //
}
