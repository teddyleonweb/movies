<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::redirect('/', 'movies');

Auth::routes();

Route::get('movies', 'Web\PageController@movies')->name('movies');


Route::get('movie/{slug}','Web\PageController@movie')->name('movie');

Route::get('categoria/{slug}','Web\PageController@categoria')->name('categoria');

//Administracion

Route::resource('categorias', 'Admin\CategoriaController');
Route::resource('themovies', 'Admin\MovieController');