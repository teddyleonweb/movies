@extends('layouts.app')


@section('content')
<div class="container">
<div class="row">
    <div class="col-md-8 col-md-offset-2">
        <div class="panel panel-default">
            <div class="panel-heading">
                Ver pelicula
            
            </div>
        </div>

<div class="panel-body">
<p><strong>Nombre: </strong>{{$movie->name}}</p>
<p><strong>Slug: </strong>{{$movie->slug}}</p>
<p><strong>Sinopsis: </strong>{{$movie->sinopsis}}</p>
<p><strong>Portada: </strong><img width="auto
    " src="{{$movie->file}}"></p>
    <p><strong>Pelicula: </strong></p>{{$movie->extracto}}
</div>

    </div>
</div>
</div>

@endsection