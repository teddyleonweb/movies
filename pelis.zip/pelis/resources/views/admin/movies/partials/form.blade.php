Formulario
{{Form::hidden('user_id',auth()->user()->id)}}

<div class="form-group">

    {{Form::label('category_id', 'Categorias')}}
    {{Form::select('category_id', $categorias, null, ['class'=>'form-control'])}}
</div>

<div class="form-group">
    {{Form::label('name','Nombre de la Pelicula')}}
    {{Form::text('name',null,['class' =>'form-control', 'id'=>'name'])}}
</div>
<div class="form-group">
    {{Form::label('slug','URL amigable')}}
    {{Form::text('slug',null,['class' =>'form-control', 'id'=>'slug'])}}
</div>

<div class="form-group">
    {{Form::label('file','Imagen')}}
    {{Form::file('file')}}
</div>
<div class="form-group">
    {{Form::label('extracto','extracto')}}
    {{Form::text('extracto', null, ['class'=>'form-control'])}}
</div>

<div class="form-group">
    {{Form::label('sinopsis','sinopsis')}}
    {{Form::textarea('sinopsis', null, ['class'=>'form-control'])}}
</div>

<div class="form-group">
    {{Form::submit('guardar',['class'=> 'btn btn-sm btn-primary'])}}
  
</div>
@section('scripts')
<script src="{{asset('vendor/stringToSlug/jquery.stringToSlug.min.js')}}
"></script>
<script src="{{asset('vendor/ckeditor/ckeditor.js')}}
"></script>

<script>
    $(document).ready(function(){
        $("#name, #slug").stringToSlug({
            callback:function(text){
                $("#slug").val(text);
            }
        })
    })
CKEDITOR.config.height =400;
CKEDITOR.config.width ='auto';

    CKEDITOR.replace('sinopsis');
</script>
@endsection