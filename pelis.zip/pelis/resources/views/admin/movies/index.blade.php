@extends('layouts.app')


@section('content')
<div class="container">
<div class="row">
    <div class="col-md-8 col-md-offset-2">
        <div class="panel panel-default">
            <div class="panel-heading">
                Lista de mis Peliculas
            <a href="{{route('themovies.create')}}" class="btn btn-sm btn-primary pull-right">Crear</a>
            </div>
        </div>

<div class="panel-body">
    <table class="table table-striped table-hover">
        <thead>
        <tr>
            <th width="10px">ID</th>
            <th>Nombre</th>
            <th colspan="3">&nbsp;</th>
        </tr>
    </thead>
    <tbody>
        @foreach ($movies as $movie)
            <tr>
            <td>{{$movie->id}}</td>
            <td>{{$movie->name}}</td>
            <td width="10px"><a class="btn btn-sm btn-default" href="{{route('themovies.show',$movie->id)}}">Ver</a></td>

            <td width="10px"><a class="btn btn-sm btn-default" href="{{route('themovies.edit',$movie->id)}}">Editar</a></td>

            <td width="10px"> {!!Form::open(['route'=>['themovies.destroy',$movie->id], 'method'=>'DELETE'])!!}
                <button class="btn btn-sm btn-danger">Eliminar</button>
                {!! Form::close()!!}</td>
           
            </tr>
        @endforeach
    </tbody>
    </table>

    {{$movies->render()}}
</div>

    </div>
</div>
</div>

@endsection