@extends('layouts.app')

@section('content')



<div class="container">
<div class="col-md-8 col-md-offset-2">
    <h1>{{$movie->name}}</h1>

    
    <div class="panel panel-default">
<div class="panel-heading">
    {{$movie->name}}
</div>
<div class="panel-body">
    @if($movie->file)
<img src="{{$movie->file}}" class="img-responsive">
<div class="sinopsis">{{$movie->sinopsis}}</div>
@endif

<a href="{{route('categoria',$movie->categoria['name'])}}" class="pull-right">{{$movie->categoria['name']}}</a>
</div>



    </div>
</div>
@endsection