@extends('layouts.app')

@section('content')



<div class="container">
<div class="col-md-8 col-md-offset-2">
    <h1>Peliculas recientemente agregadas</h1>

    @foreach($movies as $movie)
    <div class="panel panel-default">
<div class="panel-heading">
   {{$movie->name}} -- <a href="{{route('categoria',$movie->categoria['name'])}}">{{$movie->categoria['name']}}</a> 
</div>
<div class="panel-body">
    @if($movie->file)
<img src="{{$movie->file}}" class="img-responsive">
@endif
{{$movie->sinopsis}}
<a href="{{route('movie',$movie->slug)}}" class="pull-right">Ver peli </a>

</div>
@endforeach

{{$movies->render()}}
    </div>
</div>
@endsection