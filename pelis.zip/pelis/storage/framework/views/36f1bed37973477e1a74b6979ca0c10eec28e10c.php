<?php $__env->startSection('content'); ?>



<div class="container">
<div class="col-md-8 col-md-offset-2">
    <h1><?php echo e($movie->name); ?></h1>

    
    <div class="panel panel-default">
<div class="panel-heading">
    <?php echo e($movie->name); ?>

</div>
<div class="panel-body">
    <?php if($movie->file): ?>
<img src="<?php echo e($movie->file); ?>" class="img-responsive">
<div class="sinopsis"><?php echo e($movie->sinopsis); ?></div>
<?php endif; ?>

<a href="<?php echo e(route('categoria',$movie->categoria['name'])); ?>" class="pull-right"><?php echo e($movie->categoria['name']); ?></a>
</div>



    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>