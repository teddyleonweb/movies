<?php $__env->startSection('content'); ?>



<div class="container">
<div class="col-md-8 col-md-offset-2">
    <h1>Peliculas recientemente agregadas</h1>

    <?php $__currentLoopData = $movies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="panel panel-default">
<div class="panel-heading">
   <?php echo e($movie->name); ?> -- <a href="<?php echo e(route('categoria',$movie->categoria['name'])); ?>"><?php echo e($movie->categoria['name']); ?></a> 
</div>
<div class="panel-body">
    <?php if($movie->file): ?>
<img src="<?php echo e($movie->file); ?>" class="img-responsive">
<?php endif; ?>
<?php echo e($movie->sinopsis); ?>

<a href="<?php echo e(route('movie',$movie->slug)); ?>" class="pull-right">Ver peli </a>

</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php echo e($movies->render()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>