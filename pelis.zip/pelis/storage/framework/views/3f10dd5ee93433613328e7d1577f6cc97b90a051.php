Formulario
<?php echo e(Form::hidden('user_id',auth()->user()->id)); ?>


<div class="form-group">

    <?php echo e(Form::label('category_id', 'Categorias')); ?>

    <?php echo e(Form::select('category_id', $categorias, null, ['class'=>'form-control'])); ?>

</div>

<div class="form-group">
    <?php echo e(Form::label('name','Nombre de la Pelicula')); ?>

    <?php echo e(Form::text('name',null,['class' =>'form-control', 'id'=>'name'])); ?>

</div>
<div class="form-group">
    <?php echo e(Form::label('slug','URL amigable')); ?>

    <?php echo e(Form::text('slug',null,['class' =>'form-control', 'id'=>'slug'])); ?>

</div>

<div class="form-group">
    <?php echo e(Form::label('file','Imagen')); ?>

    <?php echo e(Form::file('file')); ?>

</div>
<div class="form-group">
    <?php echo e(Form::label('extracto','extracto')); ?>

    <?php echo e(Form::text('extracto', null, ['class'=>'form-control'])); ?>

</div>

<div class="form-group">
    <?php echo e(Form::label('sinopsis','sinopsis')); ?>

    <?php echo e(Form::textarea('sinopsis', null, ['class'=>'form-control'])); ?>

</div>

<div class="form-group">
    <?php echo e(Form::submit('guardar',['class'=> 'btn btn-sm btn-primary'])); ?>

  
</div>
<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('vendor/stringToSlug/jquery.stringToSlug.min.js')); ?>

"></script>
<script src="<?php echo e(asset('vendor/ckeditor/ckeditor.js')); ?>

"></script>

<script>
    $(document).ready(function(){
        $("#name, #slug").stringToSlug({
            callback:function(text){
                $("#slug").val(text);
            }
        })
    })
CKEDITOR.config.height =400;
CKEDITOR.config.width ='auto';

    CKEDITOR.replace('sinopsis');
</script>
<?php $__env->stopSection(); ?>