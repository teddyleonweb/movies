<?php $__env->startSection('content'); ?>
<div class="container">
<div class="row">
    <div class="col-md-8 col-md-offset-2">
        <div class="panel panel-default">
            <div class="panel-heading">
                Ver pelicula
            
            </div>
        </div>

<div class="panel-body">
<p><strong>Nombre: </strong><?php echo e($movie->name); ?></p>
<p><strong>Slug: </strong><?php echo e($movie->slug); ?></p>
<p><strong>Sinopsis: </strong><?php echo e($movie->sinopsis); ?></p>
<p><strong>Portada: </strong><img width="auto
    " src="<?php echo e($movie->file); ?>"></p>
    <p><strong>Pelicula: </strong></p><?php echo e($movie->extracto); ?>

</div>

    </div>
</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>